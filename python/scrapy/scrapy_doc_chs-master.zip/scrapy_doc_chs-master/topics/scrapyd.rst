.. _topics-scrapyd:

=======
Scrapyd
=======

Scrapyd被移动成为一个单独的项目。
其文档当前被托管在:

    http://scrapyd.readthedocs.org/
