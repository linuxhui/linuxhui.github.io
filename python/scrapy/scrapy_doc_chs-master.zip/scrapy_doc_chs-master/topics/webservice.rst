.. _topics-webservice:

===========
Web Service
===========

webserver 被移动到另外一个项目中。

托管在:

    https://github.com/scrapy/scrapy-jsonrpc

